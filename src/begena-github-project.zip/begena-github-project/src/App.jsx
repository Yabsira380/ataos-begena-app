import React, { useState, useEffect } from 'react';
import { Home, UserPlus, CheckSquare, CreditCard, Sparkles, UserMinus } from 'lucide-react';

import { supabase, uploadPhotoToStorage } from './services/supabase';
import {
  ethiopianMonths,
  todayEthGlobal,
  getEthiopianDate,
  formatEthDate,
  getTodayString,
  isEligibleForPaymentPeriod,
  parseInstruments,
  getDueDayForMonth,
  getPaymentStatus,
  calculateTotalAmount,
  getEarliestDate
} from './utils/ethiopian';
import { compressImage } from './utils/image';
import { EthiopianCross, WatermarkBackground } from './components/Icons';
import { LoadingSplash } from './components/LoadingSplash';
import {
  PaymentHistoryModal, LoginScreen, GlobalConfirmationModal, AiModal,
  StudentProfileModal, DashboardView, RegistrationView, AcademicView,
  LessonsView, AttendanceView, PaymentsView, ReportModal
} from './AppViews';

export default function App() {
  const [session, setSession] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [isSigningIn, setIsSigningIn] = useState(false);

  const [students, setStudents] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [academicViewType, setAcademicViewType] = useState('active');

  const ethiopianYears = ['2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026', '2027', '2028'];
  const instrumentsList = ['በገና', 'ክራር', 'ከበሮ', 'ማሲንቆ', 'ዋሽንት'];

  const [selectedYear, setSelectedYear] = useState(todayEthGlobal.year);
  const [selectedMonth, setSelectedMonth] = useState(todayEthGlobal.month);
  const [selectedDay, setSelectedDay] = useState(todayEthGlobal.day);
  const currentPeriodKey = `${selectedYear}_${selectedMonth}`;
  const [attendanceFilter, setAttendanceFilter] = useState('all'); 
  const [paymentFilter, setPaymentFilter] = useState('all'); 

  const [attendanceSearch, setAttendanceSearch] = useState('');
  const [paymentSearch, setPaymentSearch] = useState('');
  const [infoSearch, setInfoSearch] = useState('');
  const [confirmModal, setConfirmModal] = useState({ show: false, title: 'የውሳኔ ማረጋገጫ', message: '', onConfirm: () => {} });

  const [isAiOpen, setIsAiOpen] = useState(false);
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const [notification, setNotification] = useState({ show: false, message: '', type: 'success' });
  
  const [selectedStudentProfile, setSelectedStudentProfile] = useState(null);
  const [selectedStudentForHistory, setSelectedStudentForHistory] = useState(null);
  const [historyInstTab, setHistoryInstTab] = useState(null);

  const [editStudentNoState, setEditStudentNoState] = useState({ isEditing: false, value: '' });
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editFormData, setEditFormData] = useState({});

  const [selectedLessonInstrument, setSelectedLessonInstrument] = useState('በገና');
  const [isEditingLesson, setIsEditingLesson] = useState(null);
  const [editLessonForm, setEditLessonForm] = useState({ title: '', content: '' });

  const [tempScores, setTempScores] = useState({});
  const [kignitScores, setKignitScores] = useState({});
  
  const [reportConfig, setReportConfig] = useState({
    show: false,
    type: 'general',
    statusFilter: 'all'
  });

  const initialStudentState = {
    name: '', christianName: '', phone: '', emergencyContactName: '', emergencyContactPhone: '',
    workStatus: 'ተማሪ', churchService: '', parish: '', 
    instrumentType: ['በገና'], 
    paymentDetails: { 'በገና': { amount: '', date: '', startDate: getTodayString(), isFree: false, status: 'active', duration: '3 ወር' } },
    chosenDay: '', chosenTime: '', photo: '', status: 'active', examResult: '',
    registrationDate: getTodayString()
  };
  const [newStudent, setNewStudent] = useState(initialStudentState);

  const getUnpaidMonthsInfo = (student) => {
    const unpaidDetails = [];
    let totalArrears = 0;
    const insts = parseInstruments(student.instrumentType);
    
    for (const inst of insts) {
        if (student.paymentDetails?.[inst]?.isFree) continue;
        const amt = Number(student.paymentDetails?.[inst]?.amount || student.paymentAmount || 0);
        if (amt <= 0) continue;

        const instStartDate = student.paymentDetails?.[inst]?.startDate || student.registrationDate;
        
        let instUnpaidCount = 0;
        for (const y of ethiopianYears) {
            for (const m of ethiopianMonths) {
                if (!isEligibleForPaymentPeriod(instStartDate, y, m)) continue;
                const status = getPaymentStatus(student, y, m, inst);
                if (status === 'UNPAID') {
                    unpaidDetails.push(`${y}_${m}_${inst}`);
                    instUnpaidCount++;
                }
            }
        }
        totalArrears += (instUnpaidCount * amt);
    }
    return { unpaidKeys: unpaidDetails, totalArrears };
  };

  useEffect(() => {
    let mounted = true;
    
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (mounted) {
        setSession(session);
        setAuthLoading(false);
        if (session) {
          fetchStudents();
          fetchLessons();
        }
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      if (event === 'SIGNED_IN' && session) {
        fetchStudents();
        fetchLessons();
      } else if (event === 'SIGNED_OUT') {
        setStudents([]);
        setLessons([]);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('id', { ascending: true });

      if (error) throw error;

      const mappedData = data.map(s => ({
        id: s.id,
        studentNo: s.student_no,
        name: s.name,
        christianName: s.christian_name,
        phone: s.phone,
        emergencyContactName: s.emergency_contact_name,
        emergencyContactPhone: s.emergency_contact_phone,
        workStatus: s.work_status,
        churchService: s.church_service,
        parish: s.parish,
        instrumentType: s.instrument_type,
        duration: s.duration, 
        chosenDay: s.chosen_day,
        chosenTime: s.chosen_time,
        paymentAmount: s.payment_amount,
        paymentDate: s.payment_date,
        paymentDetails: s.payment_details || {},
        photo: s.photo,
        status: s.status,
        examResult: s.exam_result,
        registrationDate: s.registration_date,
        payments: s.payments || {},
        attendance: s.attendance || {},
        lesson_progress: s.lesson_progress || {},
        kignit_scores: s.kignit_scores || {} 
      }));
      setStudents(mappedData);

      const initialKignit = {};
      mappedData.forEach(s => {
         if (s.kignit_scores) initialKignit[s.id] = s.kignit_scores;
      });
      setKignitScores(initialKignit);

    } catch (err) {
      showNotification('የተማሪ መረጃዎችን ለማምጣት አልተቻለም!', 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchLessons = async () => {
    try {
      const { data, error } = await supabase.from('lessons').select('*').order('id', { ascending: true });
      if (!error && data) {
        setLessons(data);
      }
    } catch (err) {
      console.error("Lessons fetch error:", err);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsSigningIn(true);
    setAuthError('');
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      showNotification('እንኳን በደህና መጡ መምህር!', 'success');
    } catch (err) {
      setAuthError('የተሳሳተ ኢሜይል ወይም የይለፍ ቃል አስገብተዋል። እባክዎ እንደገና ይሞክሩ።');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleLogout = async () => {
    triggerConfirmation('ከአታኦስ በገና መተግበሪያ መውጣት (Logout) ይፈልጋሉ?', 'የመውጫ ማረጋገጫ', async () => {
        await supabase.auth.signOut();
        setStudents([]);
        showNotification('በተሳካ ሁኔታ ወጥተዋል!', 'success');
    });
  };

  const updateStudentInDb = async (studentId, updatedFields) => {
    try {
      const { error } = await supabase.from('students').update(updatedFields).eq('id', studentId);
      if (error) {
        console.error("Supabase Error:", error);
        showNotification(`የዳታቤዝ ስህተት: ${error.message}`, 'error');
        return false;
      }
      await fetchStudents();
      return true;
    } catch (err) {
      console.error(err);
      showNotification('ማስተካከያው አልተሳካም! ዳታቤዝ ላይ kignit_scores ኮለም መኖሩን ያረጋግጡ።', 'error');
      return false;
    }
  };

  const triggerConfirmation = (message, title, onConfirm) => {
    setConfirmModal({
      show: true, title: title || 'የውሳኔ ማረጋገጫ ሰነድ', message,
      onConfirm: () => { onConfirm(); setConfirmModal(prev => ({ ...prev, show: false })); }
    });
  };

  const showNotification = (message, type = 'success') => {
    setNotification({ show: true, message, type });
    setTimeout(() => setNotification({ show: false, message: '', type: 'success' }), 5000);
  };

  const generateNextStudentNo = () => {
    if (!students || students.length === 0) return '001';
    const maxNo = Math.max(...students.map(s => parseInt(s.studentNo || '0', 10)).filter(n => !isNaN(n)));
    return String(maxNo === -Infinity ? 1 : maxNo + 1).padStart(3, '0');
  };

  const startEditingProfile = (student) => {
    const insts = parseInstruments(student.instrumentType);
    const pDetails = student.paymentDetails || {};
    insts.forEach(i => {
       if (!pDetails[i]) pDetails[i] = { amount: '', date: '', startDate: student.registrationDate || getTodayString(), isFree: false, status: 'active', duration: student.duration || '3 ወር' };
    });

    setEditFormData({
      name: student.name,
      christian_name: student.christianName || '',
      phone: student.phone || '',
      emergency_contact_name: student.emergencyContactName || '',
      emergency_contact_phone: student.emergencyContactPhone || '',
      work_status: student.workStatus || 'ተማሪ',
      church_service: student.churchService || '',
      parish: student.parish || '',
      instrument_type: insts,
      paymentDetails: pDetails,
      chosen_day: student.chosenDay || '',
      chosen_time: student.chosenTime || '',
      registration_date: student.registrationDate || ''
    });
    setIsEditingProfile(true);
  };
  const saveProfileChanges = async (studentId) => {
    if (!editFormData.name || !editFormData.phone) {
      showNotification("እባክዎ ሙሉ ስም እና ስልክ ቁጥር መሙላቶን ያረጋግጡ!", "error");
      return;
    }
    triggerConfirmation('የተማሪውን መረጃ በእርግጥ ማስተካከል (Save) ይፈልጋሉ?', 'መረጃ ማስተካከያ', async () => {
      const payload = { 
        name: editFormData.name,
        christian_name: editFormData.christian_name,
        phone: editFormData.phone,
        emergency_contact_name: editFormData.emergency_contact_name,
        emergency_contact_phone: editFormData.emergency_contact_phone,
        work_status: editFormData.work_status,
        church_service: editFormData.church_service,
        parish: editFormData.parish,
        instrument_type: Array.isArray(editFormData.instrument_type) ? editFormData.instrument_type.join(', ') : editFormData.instrument_type,
        chosen_day: editFormData.chosen_day,
        chosen_time: editFormData.chosen_time,
        payment_details: editFormData.paymentDetails,
        payment_amount: calculateTotalAmount(editFormData.paymentDetails),
        payment_date: getEarliestDate(editFormData.paymentDetails),
        registration_date: editFormData.registration_date 
      };
      
      const success = await updateStudentInDb(studentId, payload);
      if (success) {
        showNotification('የተማሪው መረጃ በተሳካ ሁኔታ ተስተካክሏል!', 'success');
        setIsEditingProfile(false);
      }
    });
  };

  const handleStudentNoSave = async (student) => {
    let newNo = editStudentNoState.value.trim();
    if (!newNo) { showNotification("እባክዎ ትክክለኛ መለያ ቁጥር ያስገቡ", "error"); return; }
    if (/^\d+$/.test(newNo)) newNo = String(parseInt(newNo, 10)).padStart(3, '0');
    if (newNo === student.studentNo) { setEditStudentNoState({ isEditing: false, value: '' }); return; }
    triggerConfirmation(`የተማሪውን መለያ ቁጥር ከ #${student.studentNo} ወደ #${newNo} ለመቀየር እርግጠኛ ነዎት?`, 'የመለያ ቁጥር ማስተካከያ', async () => {
        const success = await updateStudentInDb(student.id, { student_no: newNo });
        if (success) {
          setSelectedStudentProfile(prev => prev ? { ...prev, studentNo: newNo } : null);
          showNotification("መለያ ቁጥሩ በተሳካ ሁኔታ ተስተካክሏል!", "success");
          setEditStudentNoState({ isEditing: false, value: '' });
        }
    });
  };

  const handleProfilePhotoChange = async (e, student) => {
    const file = e.target.files[0];
    if (!file) return;
    triggerConfirmation(`የተማሪውን ፎቶ በአዲሱ ፎቶ ለመቀየር (Edit) እርግጠኛ ነዎት?`, 'የፎቶ ማስተካከያ', async () => {
        showNotification('ፎቶ በመጭመቅ እና በመጫን ላይ...', 'success');
        const compressedImage = await compressImage(file);
        const photoUrl = await uploadPhotoToStorage(compressedImage, student.studentNo);
        const success = await updateStudentInDb(student.id, { photo: photoUrl });
        if (success) {
          setSelectedStudentProfile(prev => prev ? { ...prev, photo: photoUrl } : null);
          showNotification("ፎቶው ተቀይሮ ተቀምጧል!", "success");
        }
    });
  };

  const handleProfilePhotoRemove = async (student) => {
    triggerConfirmation(`የተማሪውን ፎቶ ሙሉ በሙሉ ለማጥፋት (Remove) እርግጠኛ ነዎት?`, 'ፎቶ ማጥፊያ', async () => {
        const success = await updateStudentInDb(student.id, { photo: '' });
        if (success) {
          setSelectedStudentProfile(prev => prev ? { ...prev, photo: '' } : null);
          showNotification("ፎቶው በተሳካ ሁኔታ ተሰርዟል! አሁን የአፑ ፍጥነት ይስተካከላል።", "success");
        }
    });
  };

  const handleAddStudentSubmit = async (e) => {
    e.preventDefault();
    if (!newStudent.name || !newStudent.phone) return;

    triggerConfirmation(`አዲስ ተማሪ "${newStudent.name}" ለመመዝገብ መረጃው ትክክል መሆኑን ያረጋግጣሉ?`, 'የተማሪ ምዝገባ ማረጋገጫ', async () => {
        const nextNo = generateNextStudentNo();
        
        let finalPhotoUrl = '';
        if (newStudent.photo && newStudent.photo.startsWith('data:image')) {
            showNotification('ፎቶ ወደ ዳታቤዝ እየተጫነ ነው፣ እባክዎ ይጠብቁ...', 'success');
            finalPhotoUrl = await uploadPhotoToStorage(newStudent.photo, nextNo);
        } else {
            finalPhotoUrl = newStudent.photo;
        }

        const studentToInsert = {
          student_no: nextNo, name: newStudent.name, christian_name: newStudent.christianName, phone: newStudent.phone,
          emergency_contact_name: newStudent.emergencyContactName, emergency_contact_phone: newStudent.emergencyContactPhone,
          work_status: newStudent.workStatus, church_service: newStudent.churchService, parish: newStudent.parish,
          instrument_type: Array.isArray(newStudent.instrumentType) ? newStudent.instrumentType.join(', ') : newStudent.instrumentType,
          chosen_day: newStudent.chosenDay, chosen_time: newStudent.chosenTime,
          payment_details: newStudent.paymentDetails,
          payment_amount: calculateTotalAmount(newStudent.paymentDetails),
          payment_date: getEarliestDate(newStudent.paymentDetails),
          photo: finalPhotoUrl, status: 'active', exam_result: '',
          registration_date: newStudent.registrationDate, payments: {}, attendance: {}, lesson_progress: {}
        };
        const { error } = await supabase.from('students').insert([studentToInsert]);
        if (error) { showNotification('ምዝገባው አልተሳካም! እባክዎ እንደገና ይሞክሩ።', 'error');
        } else {
          showNotification(`ተማሪው በመለያ ቁጥር ${nextNo} በተሳካ ሁኔታ ተመዝግቧል!`, 'success');
          setNewStudent(initialStudentState);
          fetchStudents();
        }
    });
  };

  const askToDeleteStudent = (student) => {
    triggerConfirmation(`ተማሪ "${student.name}" (መ.ቁ: #${student.studentNo}) ከማሰልጠኛ ተቋሙ ሙሉ በሙሉ እንዲሰረዝ ይፈልጋሉ? ይህ ድርጊት ወደኋላ ሊመለስ አይችልም።`, 'የተማሪ ስረዛ ማረጋገጫ', async () => {
        const { error } = await supabase.from('students').delete().eq('id', student.id);
        if (error) { showNotification('ስረዛው አልተሳካም!', 'error');
        } else {
          showNotification(`${student.name} ከዝርዝር ተሰርዟል።`, 'success');
          fetchStudents();
          if (selectedStudentProfile?.id === student.id) {
            setSelectedStudentProfile(null); setEditStudentNoState({ isEditing: false, value: '' }); setIsEditingProfile(false);
          }
        }
    });
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (file) {
      showNotification('ፎቶ በመጭመቅ ላይ...', 'success');
      const compressedImage = await compressImage(file);
      setNewStudent({ ...newStudent, photo: compressedImage });
    }
  };

  const toggleAttendanceForDay = async (studentId, periodKey, day) => {
    const student = students.find(s => s.id === studentId);
    if (!student) return;
    const updatedAttendance = { ...student.attendance };
    const periodAttendance = { ...(updatedAttendance[periodKey] || {}) };
    periodAttendance[day] = !periodAttendance[day];
    updatedAttendance[periodKey] = periodAttendance;

    const success = await updateStudentInDb(studentId, { attendance: updatedAttendance });
    if (success && selectedStudentProfile?.id === studentId) {
      setSelectedStudentProfile(prev => ({ ...prev, attendance: updatedAttendance }));
    }
  };

  const handleToggleAttendanceWithConfirm = (student, periodKey, day) => {
    const isPresent = student.attendance?.[periodKey]?.[day] || false;
    const dateText = `${selectedMonth} ${day} ቀን`;
    const actionText = isPresent ? 'አልተገኘም (Absent)' : 'ተገኝቷል (Present)';
    triggerConfirmation(`የተማሪ "${student.name}" የዕለት መገኘት በ ${dateText} ወደ "${actionText}" እንዲቀየር ይፈልጋሉ?`, 'የመገኘት ማስተካከያ', () => {
        toggleAttendanceForDay(student.id, periodKey, day); showNotification(`የ ${student.name} መገኘት ተስተካክሏል።`, 'success');
    });
  };

  const handleCalendarDayClick = (student, day) => {
    const isPresent = student.attendance?.[currentPeriodKey]?.[day] || false;
    const nextStateAmharic = isPresent ? 'እንዳልመጣ (በማቅረት)' : 'እንደመጣ (በመገኘት)';
    triggerConfirmation(`በ ${selectedMonth} ቀን ${day} ተማሪ "${student.name}" ${nextStateAmharic} እንዲመዘገብ ያረጋግጣሉ?`, 'የቀን መቁጠሪያ አቴንዳንስ ማስተካከያ', () => {
        toggleAttendanceForDay(student.id, currentPeriodKey, day); showNotification(`አቴንዳንሱ ተስተካክሏል።`, 'success');
    });
  };

  const handleTogglePaymentWithConfirm = (student, basePeriodKey, inst) => {
    const key = `${basePeriodKey}_${inst}`;
    const legacyKey = basePeriodKey;
    
    let isPaid = false;
    if (student.payments) {
        if (student.payments[key] !== undefined) {
            isPaid = student.payments[key];
        } else if (student.payments[legacyKey] !== undefined) {
            isPaid = student.payments[legacyKey];
        }
    }
    
    const actionText = isPaid ? 'አልከፈለም' : 'ከፍሏል';
    const updatedPayments = { ...student.payments, [key]: !isPaid };
    
    triggerConfirmation(`የተማሪ "${student.name}" የ ${inst} ክፍያ ሁኔታ ወደ "${actionText}" እንዲቀየር ይፈልጋሉ?`, 'የክፍያ ማረጋገጫ ሰነድ', async () => {
        const success = await updateStudentInDb(student.id, { payments: updatedPayments });
        if (success) { showNotification(`የ ${inst} ክፍያ ሁኔታ ተስተካክሏል።`, 'success'); }
    });
  };

  const setInstrumentStatusWithConfirm = (student, inst, newStatus) => {
    let statusAmharic = '';
    if (newStatus === 'completed') statusAmharic = 'ትምህርቱን ያጠናቀቀ (ምሩቅ)';
    else if (newStatus === 'dropped') statusAmharic = 'ትምህርቱን ያቋረጠ';
    else statusAmharic = 'በመማር ላይ ያለ (Active)';
    
    triggerConfirmation(`የተማሪ "${student.name}" የ ${inst} ትምህርት ሁኔታ ወደ "${statusAmharic}" እንዲለወጥ ይፈልጋሉ?`, 'የትምህርት ደረጃ ለውጥ', async () => {
        const updatedDetails = { ...student.paymentDetails };
        if (!updatedDetails[inst]) updatedDetails[inst] = { amount: '', date: '', startDate: student.registrationDate, isFree: false, duration: '3 ወር' };
        updatedDetails[inst].status = newStatus;

        const allInsts = parseInstruments(student.instrumentType);
        let allCompleted = true;
        let allDropped = true;
        allInsts.forEach(i => {
            const st = updatedDetails[i]?.status || 'active';
            if (st !== 'completed') allCompleted = false;
            if (st !== 'dropped') allDropped = false;
        });
        
        let globalStatus = 'active';
        if (allCompleted) globalStatus = 'completed';
        else if (allDropped) globalStatus = 'dropped';

        const success = await updateStudentInDb(student.id, { payment_details: updatedDetails, status: globalStatus });
        if (success) {
          if (newStatus === 'completed') showNotification(`ተማሪው የ ${inst} ትምህርቱን ማጠናቀቁ ተመዝግቧል!`, 'success');
          else if (newStatus === 'dropped') showNotification(`ተማሪው የ ${inst} ትምህርቱን ማቋረጡ ተመዝግቧል!`, 'success');
          else showNotification(`ተማሪው ወደ ${inst} ትምህርት ገበታ ተመልሷል!`, 'success');
        }
    });
  };

  const handleExamScoreSubmit = (studentId, score, kignitData = null) => {
    const student = students.find(s => s.id === studentId);
    if (!student) return;
    triggerConfirmation(`የተማሪ "${student.name}" የፈተና ውጤት መዝገብ ዳታቤዝ ላይ እንዲቀመጥ ይፈልጋሉ?`, 'የፈተና ውጤት ማረጋገጫ', async () => {
        const payload = { exam_result: score };
        if (kignitData) payload.kignit_scores = kignitData;
        const success = await updateStudentInDb(studentId, payload);
        if (success) showNotification('ውጤቱ በተሳካ ሁኔታ ተመዝግቧል!', 'success');
    });
  };

  const toggleStudentLessonProgress = async (student, lessonId) => {
    const currentProgress = { ...(student.lesson_progress || {}) };
    currentProgress[lessonId] = !currentProgress[lessonId]; 
    const success = await updateStudentInDb(student.id, { lesson_progress: currentProgress });
    if (success && selectedStudentProfile?.id === student.id) {
      setSelectedStudentProfile(prev => ({ ...prev, lesson_progress: currentProgress }));
      showNotification('የትምህርት ደረጃ ተስተካክሏል', 'success');
    }
  };

  const addLesson = async () => {
    const newLesson = { instrument: selectedLessonInstrument, title: 'አዲስ የትምህርት ርዕስ', content: 'ስለ ትምህርቱ አጭር ማብራሪያ እዚህ ይጻፉ...' };
    const { data, error } = await supabase.from('lessons').insert([newLesson]).select();
    if (!error && data) { setLessons([...lessons, ...data]); showNotification('አዲስ ትምህርት ታክሏል!', 'success'); }
  };

  const updateLesson = async (id) => {
    const { error } = await supabase.from('lessons').update(editLessonForm).eq('id', id);
    if (!error) { setIsEditingLesson(null); fetchLessons(); showNotification('ትምህርቱ ተስተካክሏል!', 'success'); }
  };

  const deleteLesson = async (id) => {
    triggerConfirmation('ይህንን ትምህርት ሙሉ በሙሉ ለማጥፋት እርግጠኛ ነዎት?', 'ትምህርት ማጥፊያ', async () => {
      const { error } = await supabase.from('lessons').delete().eq('id', id);
      if (!error) { setLessons(lessons.filter(l => l.id !== id)); showNotification('ትምህርቱ ተሰርዟል!', 'success'); }
    });
  };

  const triggerWindowPrint = () => window.print();

  const askAI = async (e) => {
    e?.preventDefault();
    if (!aiQuery.trim()) return;
    setIsAiLoading(true); setAiResponse('');
    const userQuestion = aiQuery; setAiQuery('');
    
    const summarizedStudents = students.map(s => {
      const info = getUnpaidMonthsInfo(s);
      return {
          name: s.name,
          studentNo: s.studentNo,
          status: s.status,
          instruments: s.instrumentType,
          arrearsMonths: info.unpaidKeys.length,
          totalArrears: info.totalArrears
      };
    });

    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
    const systemPrompt = `አንተ የ 'አታኦስ መንፈሳዊ የዜማ ማሰልጠኛ ተቋም' የበገና እና የዜማ መምህር የሆንክ የላቀ AI ረዳት ነህ። ተማሪዎችን በትህትና እና በመንፈሳዊ ስነ-ምግባር አገልግል። የተማሪዎች አጠቃላይ መረጃ (የተጨመቀ)፦ ${JSON.stringify(summarizedStudents)}`;

    try {
      const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: `${systemPrompt}\n\nየተማሪው ጥያቄ፦ ${userQuestion}` }] }] }) });
      const data = await res.json();
      if (data.error) setAiResponse(`የስህተት መልእክት፦ ${data.error.message}`);
      else setAiResponse(data.candidates?.[0]?.content?.parts?.[0]?.text || "ይቅርታ መምህር፣ ጥያቄዎን በሚገባ ማስተዋል አልቻልኩም።");
    } catch (error) { setAiResponse("ይቅርታ መምህር፣ ከበይነመረብ (Internet) ጋር መገናኘት አልተቻለም።"); } finally { setIsAiLoading(false); }
  };

  const copyReportToClipboard = () => showNotification('ሪፖርቱ በፅሁፍ ኮፒ ተደርጓል!', 'success');

  // --- COMPUTATIONS ---
  const activeStudents = students.filter(s => s.status === 'active');
  
  const totalPaidCurrentMonth = activeStudents.filter(s => {
      const insts = parseInstruments(s.instrumentType);
      return insts.every(inst => {
          const status = getPaymentStatus(s, selectedYear, selectedMonth, inst);
          return status === 'PAID' || status === 'SCHOLARSHIP' || status === 'CURRENT_NOT_DUE' || status === 'FUTURE_NOT_DUE';
      });
  }).length;
  
  const totalUnpaidCurrentMonth = activeStudents.filter(s => {
      const insts = parseInstruments(s.instrumentType);
      return insts.some(inst => {
          const status = getPaymentStatus(s, selectedYear, selectedMonth, inst);
          return status === 'UNPAID';
      });
  }).length;
  
  const totalRevenueExpected = activeStudents.reduce((sum, s) => {
      const insts = parseInstruments(s.instrumentType);
      return sum + insts.reduce((instSum, inst) => instSum + (s.paymentDetails?.[inst]?.isFree ? 0 : Number(s.paymentDetails?.[inst]?.amount || s.paymentAmount || 0)), 0);
  }, 0);
  
  const totalRevenueCollected = activeStudents.reduce((sum, s) => {
      const insts = parseInstruments(s.instrumentType);
      return sum + insts.reduce((instSum, inst) => {
          const status = getPaymentStatus(s, selectedYear, selectedMonth, inst);
          if (status === 'PAID') return instSum + Number(s.paymentDetails?.[inst]?.amount || s.paymentAmount || 0);
          return instSum;
      }, 0);
  }, 0);
  
  const overdueList = activeStudents.map(student => {
    const info = getUnpaidMonthsInfo(student);
    if (info.unpaidKeys.length > 0) return { ...student, ...info };
    return null;
  }).filter(Boolean);
  const overdueUnpaidCount = overdueList.length;

  const completedStudentsCount = students.filter(s => s.status === 'completed').length;
  const droppedStudentsCount = students.filter(s => s.status === 'dropped').length;
  const totalActive = activeStudents.length;
  const totalPresentToday = activeStudents.filter(s => s.attendance?.[currentPeriodKey]?.[selectedDay]).length;

  const ctx = {
    session,
    setSession,
    authLoading,
    setAuthLoading,
    email,
    setEmail,
    password,
    setPassword,
    authError,
    setAuthError,
    isSigningIn,
    setIsSigningIn,
    students,
    setStudents,
    lessons,
    setLessons,
    loading,
    setLoading,
    activeTab,
    setActiveTab,
    academicViewType,
    setAcademicViewType,
    ethiopianYears,
    instrumentsList,
    selectedYear,
    setSelectedYear,
    selectedMonth,
    setSelectedMonth,
    selectedDay,
    setSelectedDay,
    currentPeriodKey,
    attendanceFilter,
    setAttendanceFilter,
    paymentFilter,
    setPaymentFilter,
    attendanceSearch,
    setAttendanceSearch,
    paymentSearch,
    setPaymentSearch,
    infoSearch,
    setInfoSearch,
    confirmModal,
    setConfirmModal,
    isAiOpen,
    setIsAiOpen,
    aiQuery,
    setAiQuery,
    aiResponse,
    setAiResponse,
    isAiLoading,
    setIsAiLoading,
    notification,
    setNotification,
    selectedStudentProfile,
    setSelectedStudentProfile,
    selectedStudentForHistory,
    setSelectedStudentForHistory,
    historyInstTab,
    setHistoryInstTab,
    editStudentNoState,
    setEditStudentNoState,
    isEditingProfile,
    setIsEditingProfile,
    editFormData,
    setEditFormData,
    selectedLessonInstrument,
    setSelectedLessonInstrument,
    isEditingLesson,
    setIsEditingLesson,
    editLessonForm,
    setEditLessonForm,
    tempScores,
    setTempScores,
    kignitScores,
    setKignitScores,
    reportConfig,
    setReportConfig,
    initialStudentState,
    newStudent,
    setNewStudent,
    getUnpaidMonthsInfo,
    fetchStudents,
    fetchLessons,
    handleLogin,
    handleLogout,
    updateStudentInDb,
    triggerConfirmation,
    showNotification,
    generateNextStudentNo,
    startEditingProfile,
    saveProfileChanges,
    handleStudentNoSave,
    handleProfilePhotoChange,
    handleProfilePhotoRemove,
    handleAddStudentSubmit,
    askToDeleteStudent,
    handlePhotoUpload,
    toggleAttendanceForDay,
    handleToggleAttendanceWithConfirm,
    handleCalendarDayClick,
    handleTogglePaymentWithConfirm,
    setInstrumentStatusWithConfirm,
    handleExamScoreSubmit,
    toggleStudentLessonProgress,
    addLesson,
    updateLesson,
    deleteLesson,
    triggerWindowPrint,
    askAI,
    copyReportToClipboard,
    activeStudents,
    totalPaidCurrentMonth,
    totalUnpaidCurrentMonth,
    totalRevenueExpected,
    totalRevenueCollected,
    overdueList,
    overdueUnpaidCount,
    completedStudentsCount,
    droppedStudentsCount,
    totalActive,
    totalPresentToday
  };

  if (authLoading) {
    return <LoadingSplash message="የደህንነት ማረጋገጫ በመካሄድ ላይ ነው..." />;
  }

  if (!session) {
    return <LoginScreen ctx={ctx} />;
  }

  if (loading) {
    return <LoadingSplash message="የተማሪዎች መረጃ ከዳታቤዝ በመጫን ላይ ነው..." />;
  }

  return (
    <>
      <ReportModal ctx={ctx} />
      <PaymentHistoryModal ctx={ctx} />
      <AiModal ctx={ctx} />

      <div className="app-ui hide-on-print min-h-screen bg-[#FAF6EE] flex flex-col pb-24 relative overflow-x-hidden">
        <header className="bg-[#3E2723] text-white px-4 py-3 flex justify-between items-center border-b-4 border-[#D4AF37] shadow-md relative z-20">
          <div className="flex items-center space-x-2">
            <EthiopianCross className="w-5 h-5 text-[#D4AF37]" />
            <span className="font-black text-sm sm:text-base font-serif text-[#FFF8E7]">አታኦስ በገና ማሰልጠኛ</span>
          </div>
          <button onClick={handleLogout} className="bg-red-700/80 hover:bg-red-800 text-white px-3 py-1.5 rounded-xl text-xs font-black transition-all active:scale-95 flex items-center gap-1 shadow-sm border border-red-500/30">
            <UserMinus size={14} /> ውጣ (Logout)
          </button>
        </header>

        <WatermarkBackground />

        <main className="flex-1 max-w-md mx-auto w-full relative z-10">
          {notification.show && (
            <div className={`fixed top-16 left-4 right-4 p-3 rounded-2xl shadow-xl flex items-center space-x-3 border-2 z-[200] animate-fade-in ${notification.type === 'success' ? 'bg-[#E8F5E9] border-green-500 text-[#1B5E20]' : 'bg-[#FFEBEE] border-[#F44336] text-[#B71C1C]'}`}>
              {notification.message}
            </div>
          )}

          <GlobalConfirmationModal ctx={ctx} />
          <StudentProfileModal ctx={ctx} />

          {activeTab === 'dashboard' && <DashboardView ctx={ctx} />}
          {activeTab === 'students' && <RegistrationView ctx={ctx} />}
          {activeTab === 'academic' && <AcademicView ctx={ctx} />}
          {activeTab === 'lessons' && <LessonsView ctx={ctx} />}
          {activeTab === 'attendance' && <AttendanceView ctx={ctx} />}
          {activeTab === 'payments' && <PaymentsView ctx={ctx} />}
        </main>

        {!isAiOpen && (
          <button 
            onClick={() => setIsAiOpen(true)}
            className="fixed bottom-24 right-5 bg-gradient-to-r from-[#D4AF37] to-[#8B5A2B] text-white p-4 rounded-full shadow-[0_4px_15px_rgba(139,90,43,0.4)] z-[100] hover:scale-105 active:scale-95 transition-transform flex items-center justify-center animate-bounce-subtle"
          >
            <Sparkles size={24} />
          </button>
        )}

        <nav className="fixed bottom-0 left-0 right-0 bg-[#FAF3E0]/95 backdrop-blur-md border-t-4 border-[#8B5A2B] px-2 py-2 flex justify-between items-center z-50 shadow-[0_-4px_10px_rgba(0,0,0,0.1)]">
          {[
            { id: 'dashboard', icon: Home, label: 'ዋና' },
            { id: 'students', icon: UserPlus, label: 'መዝግብ' },
            { id: 'academic', icon: BookOpen, label: 'መረጃ' },
            { id: 'lessons', icon: ListMusic, label: 'አታኦስ' },
            { id: 'attendance', icon: CheckSquare, label: 'መገኘት' },
            { id: 'payments', icon: CreditCard, label: 'ክፍያ' },
          ].map((item) => (
            <button 
              key={item.id} 
              onClick={() => {
                setActiveTab(item.id);
                if (item.id === 'attendance') setAttendanceFilter('all');
                if (item.id === 'payments') setPaymentFilter('all');
              }} 
              className={`flex flex-col items-center justify-center w-14 h-12 rounded-2xl transition-all duration-300 relative ${
                activeTab === item.id 
                  ? 'bg-[#8B5A2B]/10 text-[#8B5A2B] transform -translate-y-1' 
                  : 'text-[#8D6E63] hover:bg-[#8B5A2B]/5 hover:text-[#5C4033]'
              }`}
            >
              <item.icon size={20} className={activeTab === item.id ? "mb-0.5" : ""} />
              <span className={`text-[9px] font-black transition-all ${activeTab === item.id ? 'opacity-100' : 'opacity-70'}`}>
                {item.label}
              </span>
              {activeTab === item.id && (
                 <div className="absolute -bottom-2 w-4 h-1 rounded-full bg-[#8B5A2B]" />
              )}
            </button>
          ))}
        </nav>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @import url('https://fonts.googleapis.com/css2?family=Noto+Serif+Ethiopic:wght@400;700;900&display=swap');
        body { font-family: 'Noto Serif Ethiopic', serif; margin: 0; padding: 0; background-color: #FAF6EE; min-height: 100vh; color: #3E2723; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade-in { animation: fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        
        @keyframes bounceSubtle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        .animate-bounce-subtle { animation: bounceSubtle 2s infinite ease-in-out; }
        
        input::-webkit-outer-spin-button, input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        
        @media print {
          body, html { 
            background-color: white !important; 
            color: black !important; 
            height: auto !important; 
            margin: 0 !important; 
            padding: 0 !important; 
            overflow: visible !important;
          }
          .app-ui, .hide-on-print { 
            display: none !important; 
          }
          .hide-on-print-bg { 
            position: absolute !important; 
            background: white !important; 
            inset: 0 !important;
            overflow: visible !important; 
            z-index: 9999 !important;
          }
          #printable-area {
            display: block !important;
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: 20px !important;
            box-shadow: none !important;
            border: none !important;
            border-radius: 0 !important;
            background: white !important;
          }
        }
      `}} />
    </>
  );
}