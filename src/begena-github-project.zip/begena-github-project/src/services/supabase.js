import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const uploadPhotoToStorage = async (dataUrl, identifier) => {
  if (!dataUrl || !dataUrl.startsWith('data:image')) return dataUrl;

  try {
    const arr = dataUrl.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);

    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }

    const blob = new Blob([u8arr], { type: mime });
    const fileName = `photo_${identifier}_${Date.now()}.jpg`;

    const { error } = await supabase.storage
      .from('student-photos')
      .upload(fileName, blob, { upsert: true });

    if (error) throw error;

    const { data: publicUrlData } = supabase.storage
      .from('student-photos')
      .getPublicUrl(fileName);

    return publicUrlData.publicUrl;
  } catch (err) {
    console.error('Photo upload error:', err);
    return '';
  }
};
