export const ethiopianMonths = ['መስከረም', 'ጥቅምት', 'ኅዳር', 'ታኅሣሥ', 'ጥር', 'የካቲት', 'መጋቢት', 'ሚያዝያ', 'ግንቦት', 'ሰኔ', 'ሐምሌ', 'ነሐሴ', 'ጳጉሜ'];

// --- Ethiopian Real-time Date Calculation Function ---
export const getEthiopianDate = (date = new Date()) => {
  const gYear = date.getFullYear();
  const gMonth = date.getMonth() + 1;
  const gDay = date.getDate();

  const isGregLeap = (gYear % 4 === 0 && gYear % 100 !== 0) || (gYear % 400 === 0);
  const gMonthDays = [0, 31, isGregLeap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  let dayOfYear = gDay;
  for (let i = 1; i < gMonth; i++) dayOfYear += gMonthDays[i];

  const sept11Day = isGregLeap ? 255 : 254;

  let eYear, eMonthIdx, eDay;

  if (dayOfYear >= sept11Day) {
    eYear = gYear - 7;
    const diff = dayOfYear - sept11Day;
    eMonthIdx = Math.floor(diff / 30);
    eDay = (diff % 30) + 1;
  } else {
    eYear = gYear - 8;
    const prevLeap = ((gYear - 1) % 4 === 0 && (gYear - 1) % 100 !== 0) || ((gYear - 1) % 400 === 0);
    const prevYearDays = prevLeap ? 366 : 365;
    const prevSept11 = prevLeap ? 255 : 254;
    const diff = (prevYearDays - prevSept11) + dayOfYear;
    eMonthIdx = Math.floor(diff / 30);
    eDay = (diff % 30) + 1;
  }

  if (eMonthIdx > 12) eMonthIdx = 12;

  return {
    year: String(eYear),
    month: ethiopianMonths[eMonthIdx] || 'መስከረም',
    day: eDay
  };
};

export const formatEthDate = (dateStr) => {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  const eth = getEthiopianDate(d);
  return `${eth.month} ${eth.day}፣ ${eth.year}`;
};

export const getTodayString = () => {
  const eatTime = new Date(new Date().getTime() + 3 * 60 * 60 * 1000);
  return eatTime.toISOString().split('T')[0];
};

// ---------------- የክፍያ ወር እና የመመዝገቢያ ወር ማወዳደሪያ ----------------
export const isEligibleForPaymentPeriod = (regDateStr, selYearStr, selMonthStr) => {
  if (!regDateStr) return true;
  const regDate = new Date(regDateStr);
  if (isNaN(regDate.getTime())) return true;
  const regEth = getEthiopianDate(regDate);
  
  const regYear = parseInt(regEth.year, 10);
  const selYear = parseInt(selYearStr, 10);
  
  if (selYear < regYear) return false;
  if (selYear > regYear) return true;
  
  const regMonthIndex = ethiopianMonths.indexOf(regEth.month);
  const selMonthIndex = ethiopianMonths.indexOf(selMonthStr);
  
  return selMonthIndex >= regMonthIndex;
};

// --- የመሳሪያ ስሞችን ወደ አሬይ (Array) የሚቀይር አጋዥ ፈንክሽን ---
export const parseInstruments = (instData) => {
  if (!instData) return ['በገና'];
  if (Array.isArray(instData)) return instData.length > 0 ? instData : ['በገና'];
  return String(instData).split(',').map(s => s.trim()).filter(Boolean);
};

// ---------------- ማዕከላዊ የክፍያ ማሽን ----------------
export const todayEthGlobal = getEthiopianDate();

export const getDueDayForMonth = (student, cY, cMIdx, inst) => {
    let regYear = 0;
    let regMonthIdx = 0;
    let regDay = 1;

    // ለስሌቱ የመሳሪያውን የጀመረበትን ቀን ይጠቀማል (ከሌለ አጠቃላይ የምዝገባ ቀኑን)
    const instStartDate = student.paymentDetails?.[inst]?.startDate || student.registrationDate;

    if (instStartDate) {
        const eth = getEthiopianDate(new Date(instStartDate));
        regYear = parseInt(eth.year, 10);
        regMonthIdx = ethiopianMonths.indexOf(eth.month);
        regDay = parseInt(eth.day, 10);
    }

    if (cY === regYear && cMIdx === regMonthIdx) {
        return regDay;
    } else {
        const instDate = student.paymentDetails?.[inst]?.date;
        if (instDate && instDate !== '') {
            return parseInt(instDate, 10);
        } else {
            return regDay < 30 ? regDay + 1 : 1;
        }
    }
};
export const getPaymentStatus = (student, targetYearStr, targetMonthStr, inst) => {
    const tY = parseInt(todayEthGlobal.year, 10);
    const tMIdx = ethiopianMonths.indexOf(todayEthGlobal.month);
    const tDay = parseInt(todayEthGlobal.day, 10);

    const cY = parseInt(targetYearStr, 10);
    const cMIdx = ethiopianMonths.indexOf(targetMonthStr);

    const instStartDate = student.paymentDetails?.[inst]?.startDate || student.registrationDate;

    // የመሳሪያውን የጀመረበትን ቀን ተጠቅሞ ታሪኩ መታየት እንዳለበት ያረጋግጣል
    if (!isEligibleForPaymentPeriod(instStartDate, targetYearStr, targetMonthStr)) {
        return 'NOT_ELIGIBLE';
    }

    const key = `${targetYearStr}_${targetMonthStr}_${inst}`;
    const legacyKey = `${targetYearStr}_${targetMonthStr}`; 
    
    let isPaid = false;
    if (student.payments) {
        if (student.payments[key] !== undefined) {
            isPaid = student.payments[key];
        } else if (student.payments[legacyKey] !== undefined) {
            isPaid = student.payments[legacyKey];
        }
    }

    if (isPaid) {
        return 'PAID';
    }
    
    if (student.paymentDetails?.[inst]?.isFree || (Number(student.paymentAmount || 0) === 0 && !student.paymentDetails?.[inst])) {
        return 'SCHOLARSHIP';
    }

    const dueDay = getDueDayForMonth(student, cY, cMIdx, inst);

    if (cY > tY || (cY === tY && cMIdx > tMIdx)) {
        return 'FUTURE_NOT_DUE';
    }

    if (cY === tY && cMIdx === tMIdx) {
        if (tDay < dueDay) {
            return 'CURRENT_NOT_DUE';
        } else {
            return 'UNPAID';
        }
    }

    return 'UNPAID';
};

export const calculateTotalAmount = (details) => {
  if (!details) return 0;
  return Object.values(details).reduce((sum, item) => sum + (item.isFree ? 0 : Number(item.amount || 0)), 0);
};

export const getEarliestDate = (details) => {
  if (!details) return '';
  const dates = Object.values(details).map(item => Number(item.date)).filter(d => !isNaN(d) && d > 0);
  return dates.length > 0 ? Math.min(...dates).toString() : '';
};
