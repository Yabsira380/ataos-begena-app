import React from 'react';


export const EthiopianCross = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 100 100" className={className} fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M 45 10 L 55 10 L 55 35 L 80 35 L 80 45 L 55 45 L 55 55 L 70 55 L 70 65 L 55 65 L 55 85 L 65 85 L 65 95 L 35 95 L 35 85 L 45 85 L 45 65 L 30 65 L 30 55 L 45 55 L 45 45 L 20 45 L 20 35 L 45 35 Z" />
    <circle cx="50" cy="50" r="4" fill="none" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

export const BegenaIcon = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" stroke="currentColor" strokeWidth="3" xmlns="http://www.w3.org/2000/svg">
    <path d="M 30 20 L 70 20 L 63 85 L 37 85 Z" strokeWidth="4" />
    <path d="M 38 20 L 38 85 M 46 20 L 46 85 M 54 20 L 54 85 M 62 20 L 62 85" strokeWidth="1.5" strokeDasharray="1,2" />
    <path d="M 30 32 L 70 32 M 34 75 L 66 75" strokeWidth="2.5" />
  </svg>
);
export const AxumObelisk = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 100 100" className={className} fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M 46 90 L 48 15 L 46 15 L 46 10 L 54 10 L 54 15 L 52 15 L 54 90 Z" />
    <rect x="48" y="22" width="4" height="3" fill="none" stroke="background" strokeWidth="1" />
    <rect x="48" y="35" width="4" height="3" fill="none" stroke="background" strokeWidth="1" />
    <rect x="48" y="48" width="4" height="3" fill="none" stroke="background" strokeWidth="1" />
    <rect x="48" y="61" width="4" height="3" fill="none" stroke="background" strokeWidth="1" />
    <rect x="48" y="74" width="4" height="3" fill="none" stroke="background" strokeWidth="1" />
  </svg>
);

export const WatermarkBackground = () => (
  <div className="absolute inset-0 pointer-events-none opacity-[0.04] flex items-center justify-center overflow-hidden z-0">
    <div className="grid grid-cols-2 gap-20 transform rotate-12">
      <EthiopianCross className="w-48 h-48 text-[#8B5A2B]" />
      <BegenaIcon className="w-48 h-48 text-[#8B5A2B]" />
      <AxumObelisk className="w-48 h-48 text-[#8B5A2B]" />
      <EthiopianCross className="w-48 h-48 text-[#8B5A2B]" />
    </div>
  </div>
);

