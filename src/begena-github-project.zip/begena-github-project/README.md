# አታኦስ በገና ማሰልጠኛ

React + Vite + Supabase application for managing students, attendance, payments, lessons, exams and reports.

## Project structure

```text
src/
├── App.jsx                 # Main state, Supabase actions and app shell
├── AppViews.jsx            # Dashboard, registration, academic, attendance, payment and report views
├── components/
│   ├── Icons.jsx           # Ethiopian/Begena custom SVG icons
│   └── LoadingSplash.jsx   # Loading screen
├── services/
│   └── supabase.js         # Supabase client and photo upload
├── utils/
│   ├── ethiopian.js        # Ethiopian calendar and payment calculations
│   └── image.js            # Image compression
├── index.css
└── main.jsx
```

## Run locally

1. Install Node.js.
2. Copy `.env.example` to `.env`.
3. Add your Supabase and Gemini API values.
4. Install packages:

```bash
npm install
```

5. Start the app:

```bash
npm run dev
```

## GitHub

Upload the whole project folder, not only `App.jsx`.

Do not upload `.env`. GitHub should contain `.env.example` only.

The existing application logic and Supabase field names from the original `App.jsx` have been kept while separating the large file into smaller modules.
